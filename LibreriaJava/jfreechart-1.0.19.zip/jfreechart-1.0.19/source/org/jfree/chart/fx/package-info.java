/**
 * Core classes that provide JavaFX support for JFreeChart.
 */
package org.jfree.chart.fx;
